/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./*.{html,css,js}"],
  // safelist: ["hover"],
  theme: {
    extend: {},
  },
  plugins: [],
};
